# Hemy 360 — Model QA/QC (Revit 2027 add-in)

Checks that model elements carry the asset data the Hemy 360 information requirements demand,
before the model is officially published. A BIM specialist picks elements by **Asset Name**, chooses
which parameters must be present *and* valid, runs the check, and exports the result to Excel —
clicking a failing row selects and zooms to that element in the model.

Implemented from the Claude Design prototype in `project/Hemy360 Model QAQC Plugin.dc.html`.

> ### Build status
> **Compiles clean — 0 errors, 0 warnings**, with the .NET 10.0.111 SDK against the pinned
> `Nice3point.Revit.Api.* 2027.2.0` reference assemblies. All nine XAML files compile through to
> BAML, which also validates the markup: well-formed XML, every element and property resolving to
> a real type, and `x:Class` matching each code-behind.
>
> The Revit-free layers are additionally **executed** — `tests/Hemy360.Qaqc.Verify` runs 62 checks
> over the validation rules, scoring, Excel export and persistence, and the workbooks it produces
> are opened by an independent OOXML reader with warnings treated as errors.
>
> **What has not run yet is anything needing the host:** the Revit API calls and the WPF rendering.
> Every Revit member used was verified against the 2027 reference assemblies' documentation XML
> (14 MB of real signatures), but static verification is not the same as loading in Revit — see
> [First run in Revit](#first-run-in-revit).

---

## Prerequisites

| | |
|---|---|
| Autodesk Revit | **2027** (the API packages are pinned to `2027.2.0`) |
| .NET SDK | **10.0** — Revit 2027's API targets `net10.0-windows7.0` |
| IDE | Visual Studio 2022 17.14+ / 2026, or `dotnet` CLI |
| OS | Windows x64 |

## Build

```powershell
dotnet build src/Hemy360.Qaqc/Hemy360.Qaqc.csproj -c Release
```

On Windows this also **deploys automatically** to your per-user add-in folder:

```
%APPDATA%\Autodesk\Revit\Addins\2027\
├─ Hemy360.Qaqc.addin
└─ Hemy360.Qaqc\
   └─ Hemy360.Qaqc.dll
```

Skip the deploy step with `-p:DeployToRevit=false`. To build on a non-Windows CI agent, the project
already sets `EnableWindowsTargeting=true`.

Start Revit, then **Hemy 360 → Model QA/QC → Model QA/QC** to open the panel. It docks right by
default and is hidden until you click the button.

### Packaging an installer

To produce a single self-contained `.exe` for distributing to a team, rather than deploying to your
own machine:

```powershell
cd installer
.\build-installer.ps1
```

It compiles the add-in and packages it, installing all-users to
`C:\ProgramData\Autodesk\Revit\Addins\2027\`. See [`installer/README.md`](../../installer/README.md)
for prerequisites, silent-deployment flags and upgrade notes.

### Changing the Revit version

The API packages are pinned on purpose — building against a package newer than your installed Revit
update can bind to API the host does not have. To retarget, change `RevitVersion` and both
`PackageReference` versions in `Hemy360.Qaqc.csproj`. Note that a different Revit major version may
also need a different `TargetFramework`.

---

## Configuration — mapping your shared parameters

The Hemy 360 parameter names shipped here are defaults. On first run the add-in writes a
self-documenting settings file:

```
%APPDATA%\Hemy Solutions\Hemy 360 QAQC\settings.json
```

```jsonc
{
  "AssetNameParameterName": "Asset Name",   // how elements are identified in the search
  "IncludeTypeParameters": true,            // count a value found on the family type
  "ParameterMappings": {
    "assetIdGuid": {
      "RevitParameterName": "Asset ID",
      "SharedParameterGuid": null           // set this and it wins over the name
    },
    "mmiLevel": { "RevitParameterName": "MMI Level", "SharedParameterGuid": null }
    // …one entry per parameter
  }
}
```

- **`RevitParameterName`** — the parameter actually holding this data in your model.
- **`SharedParameterGuid`** — set it for parameters from a shared-parameter file and the check keeps
  working after somebody renames them. Tried *before* the name.
- **`IncludeTypeParameters`** — asset data is often authored on the family type and inherited by
  instances; leave `true` unless you want to require instance-level data.

Restart Revit after editing. Saved checklist templates live beside it in
`checklist-templates.json`.

### Default parameter set

| Checklist label | Default Revit parameter | Rule |
|---|---|---|
| Asset ID (GUID) | `Asset ID` | GUID format |
| Asset name | `Asset Name` | Non-empty |
| Component instance number | `Component Instance Number` | Numeric |
| Functional location | `Functional Location` | Non-empty |
| Generic hard asset | `Generic Hard Asset` | Allowed: Yes, No |
| System | `System` | Non-empty |
| System instance number | `System Instance Number` | Numeric |
| MMI level | `MMI Level` | Allowed: MMI 100–500 |
| Asset status | `Asset Status` | Allowed: Active, Maintenance, Inactive, Archived |
| Manufacturer | `Manufacturer` | Non-empty |

**The checklist starts empty.** The operator adds the requirements they want to enforce one at a
time, so a run only ever checks what was deliberately asked for. Each requirement's rule is
overridable per row, and free-text custom parameters can be added alongside.

The picker offers **only the project and shared parameters this model defines** — nothing shipped.
It is a type-to-filter field, not a dropdown, because a real project defines hundreds of
parameters: type part of a name, the best match leads the list, and Enter or **Add** takes it.
Clicking a row adds it directly.

| Label | Source |
|---|---|
| Shared parameter | from a shared-parameter file (`Document.ParameterBindings`, `SharedParameterElement`) |
| Project parameter | defined in this document |

The requirement table above is **no longer offered as picker entries**. It names parameters
(`Asset ID`, `MMI Level`) that a given project may simply not define, so every check against them
reported "Missing" and the entries were noise. It is still consulted for *how to validate*: when a
model parameter's name matches a row in that table, the checklist row inherits its rule — GUID
format, allowed values — instead of a bare presence check, and keeps that row's key so templates
and `settings.json` still line up. Everything else starts as a presence check and can be tightened
per row. A shared parameter's GUID is carried through, so a check survives the parameter being
renamed.

Built-in and family parameters are deliberately **not** listed. An earlier version also swept the
parameters carried by chosen elements, which buried the project's own asset parameters under
hundreds of entries like Comments, Mark and Volume.

Discovery runs when the panel opens and on each re-run, and is cached in between. **Add a project
or shared parameter in Revit while the panel is open and it will not appear until the next run** —
re-run the check, or close and reopen the pane.

Two templates ship as an optional one-click shortcut: **Door — Hemy360 IR** (the nine parameters
from the original request) and **MEP Equipment — Hemy360 IR**. Loading one replaces the whole
checklist. Any checklist can be saved as a named template of its own.

Validation is deliberately **strict on format** — `{8f14e45f-…}` fails the GUID rule because the
requirement is a bare 8-4-4-4-12 hex GUID, and `1a` fails the numeric rule. The point is to catch
data that would fail an information-requirement audit, not to be forgiving.

The one deliberate leniency is that **allowed-value matching ignores case** (`yes` satisfies
`Yes`), on the grounds that casing is not what an enumerated-value requirement is about. Change
`StringComparer.OrdinalIgnoreCase` in `Domain/ParameterValidator.cs` if you want it exact.

---

## Architecture

```
src/Hemy360.Qaqc/
├─ App/            Revit entry points: ribbon button, pane registration, runtime-drawn icon
├─ Domain/         Parameter library, validation rules, checklist, scoring  ← no Revit types
├─ Revit/          Element scan, parameter reading, select/zoom, API-thread marshalling
├─ Export/         Dependency-free .xlsx writer + report builder
├─ Persistence/    settings.json and checklist-templates.json
└─ UI/             WPF dockable pane (MVVM) + design-token theme
```

Three decisions worth knowing about:

**Everything Revit-side runs through an `ExternalEvent`.** A dockable pane is modeless, so code
reached from a button click is *not* inside a Revit API context; touching the API there is
unsupported and can destabilise Revit. `Revit/RevitTaskRunner.cs` queues work onto an external
event and hands back a `Task`, so view models just `await`.

**The domain layer has no Revit dependency.** `Domain/` takes `ElementSnapshot` records and returns
results, so the compliance rules are unit-testable without Revit in the loop.

**The Excel writer has no third-party dependency.** `Export/XlsxWriter.cs` emits OOXML directly over
`System.IO.Compression`. ClosedXML/EPPlus would have been less code, but shipping their transitive
assemblies into Revit's shared load context is a well-known source of add-in conflicts. Its output
was validated by round-tripping generated parts through an independent OOXML reader.

---

## Where this departs from the prototype

Intentional, and worth reviewing:

1. **The panel is a docked pane, not a floating card.** The prototype draws a 460px rounded card
   with a drop shadow over a mock Revit viewport — that framing was there to show the panel *in
   context*. Docked, the pane fills its host area, so the card's radius, shadow and fixed width are
   gone. Everything inside is reproduced exactly.
2. **Real data replaces the 20 fake elements.** The element list is a real
   `FilteredElementCollector` scan for elements with a non-empty Asset Name, cached and refreshed on
   each run.
3. **Export produces a real `.xlsx`**, not the prototype's CSV, with three sheets (Summary,
   Elements, Parameter detail) — and the summary sheet records the checklist that produced the run,
   since a pass rate means nothing without knowing what was asked.
4. **"Select in model" really selects and zooms** via `Selection.SetElementIds` + `ShowElements` +
   `UIView.ZoomAndCenterRectangle`, rather than showing a toast.
5. **The run's 700 ms fake delay is gone**; the run takes however long reading the parameters takes.
6. **Two CSS properties have no WPF equivalent** and were handled or dropped: `text-transform`
   (done with a converter at the binding) and `letter-spacing` on `TextBlock` (dropped — the
   0.04em tracking on the small uppercase headings is not reproduced).
7. **Toast auto-dismiss is 3.2 s**, matching the prototype.

Not carried over: the prototype's `defaultTemplateKey` / `prefillCategory` / `autoRunDemo` props,
which existed to drive design-tool previews. The panel starts with an empty selection.

---

## Tests

```powershell
dotnet run --project tests\Hemy360.Qaqc.Verify -c Release
```

62 checks over the validation rules, scoring, Excel export and persistence. It targets plain
`net10.0` and compiles the Revit-free layers in as source, so it runs on any OS without Revit or a
Windows desktop runtime — the payoff for keeping `Domain/`, `Export/` and `Persistence/` free of
Revit types. Exits non-zero on failure, so it drops straight into CI.

Cases mirror the prototype's own fixture data (`ASSET-103` and `BAD-GUID` must fail the GUID rule,
`Maybe` must fail the Yes/No rule), making it parity verification against the design rather than
just a smoke test.

## First run in Revit

Compilation and the Revit-free layers are verified; these are the things only the host can settle,
in rough order of risk:

- [ ] **XAML resource URIs resolve at runtime.** They use
      `pack://application:,,,/Hemy360.Qaqc;component/UI/Theme/…`. The markup compiles, but pack
      URIs are resolved when the pane is first shown, and they depend on `AssemblyName` staying
      `Hemy360.Qaqc`. A failure here shows up as an exception on opening the panel, not at build.
- [ ] **The element scan finishes acceptably** on your largest federated model — it reads one
      parameter on every non-type model element. If it drags, narrow it by category in
      `Revit/ElementScanner.cs`.
- [ ] **Yes/No and localisation.** `Generic Hard Asset` is read via `Parameter.AsValueString()`,
      which returns Revit's *localised* Yes/No. On a non-English Revit, update the allowed values.
- [ ] **The autocomplete `Popup`** behaves when the pane is floating vs docked.
- [ ] **`Inter` font.** Falls back to Segoe UI when not installed, per the design system's stack.

## Known limitations

- **Read-only.** It reports problems; it does not write parameters. There is no `Transaction`
  anywhere, which is why it cannot corrupt a model. Batch-fixing would be the natural next feature.
- **Single document.** Reads the active document only; linked models are not traversed.
- **Element ids are not stable across sessions.** A report exported today references ids valid for
  that session's document state; re-run rather than reusing an old export as a work list.
- **The Revit and WPF layers have no automated coverage.** They cannot run outside Revit on
  Windows, so `tests/Hemy360.Qaqc.Verify` deliberately stops at the Revit-free boundary. Those
  layers were verified statically only.
